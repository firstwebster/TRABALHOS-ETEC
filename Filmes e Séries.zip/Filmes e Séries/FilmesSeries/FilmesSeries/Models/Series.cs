﻿using System;
using SQLite;


namespace FilmesSeries.Models
{
    public class Series
    {
        [PrimaryKey, AutoIncrement]
        public int IDSerie { get; set; }
        public string NomeSerie { get; set; }
        public string GeneroSerie { get; set; }
        public int TemporadasSerie { get; set; }
        public string PlataformaSerie { get; set; }
        public string URLCapaSerie { get; set; }

    }
}
