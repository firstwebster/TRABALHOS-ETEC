﻿using System;
using SQLite;


namespace FilmesSeries.Models
{
    public class Filmes
    {
        [PrimaryKey, AutoIncrement]
        public int IDFilme { get; set; }
        public string NomeFilme { get; set; }
        public string GeneroFilme { get; set; }
        public int DuracaoFilme { get; set; }
        public string PlataformaFilme { get; set; }
        public string URLCapaFilme { get; set; }

    }
}
