﻿using System;
using SQLite;


namespace FilmesSeries.Models
{
    public class Plataformas
    {
        [PrimaryKey, AutoIncrement]
        public int IDPlataforma { get; set; }
        public string NomePlataforma { get; set; }
        public double ValorAssinaturaPlataforma { get; set; }
        public string URLLogoPlataforma { get; set; }

    }
}
